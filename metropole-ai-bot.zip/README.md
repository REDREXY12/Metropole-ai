# Metropole AI Bot

Separate AI Discord bot for Metropole Studio.

## Commands
- `/ai question:<text>`
- `/ai-clear`
- `/ai-status`
- `/ai-setup`

## Pterodactyl
Rename `.env.example` to `.env`, fill in the values, then run:
`npm install`
`npm start`

Node.js 20+ is recommended.

## Automatic AI channel
Set `AUTO_CHAT_CHANNEL_ID` to a channel ID to make the bot answer normal messages in that channel. Leave it blank to disable.

## Security
Never share your Discord token or AI API key. AI API usage may incur charges.

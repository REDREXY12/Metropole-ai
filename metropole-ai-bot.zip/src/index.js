require("dotenv").config();
const {Client,GatewayIntentBits,Partials,REST,Routes,SlashCommandBuilder,PermissionFlagsBits,EmbedBuilder}=require("discord.js");
const fs=require("fs"),path=require("path");

for(const k of ["DISCORD_TOKEN","CLIENT_ID","GUILD_ID","OPENAI_API_KEY"]){
  if(!process.env[k]){console.error(`❌ Missing ${k} in .env`);process.exit(1);}
}
const C={
 token:process.env.DISCORD_TOKEN,clientId:process.env.CLIENT_ID,guildId:process.env.GUILD_ID,
 apiKey:process.env.OPENAI_API_KEY,model:process.env.OPENAI_MODEL||"gpt-6-luna",
 aiChannelId:process.env.AI_CHANNEL_ID||"",autoChatChannelId:process.env.AUTO_CHAT_CHANNEL_ID||"",
 ownerId:process.env.OWNER_ID||"",cooldownMs:Math.max(0,Number(process.env.USER_COOLDOWN_SECONDS||8)*1000),
 maxHistory:Math.max(2,Number(process.env.MAX_HISTORY_MESSAGES||12)),
 maxOutput:Math.max(500,Number(process.env.MAX_OUTPUT_CHARS||3500)),
 botName:process.env.BOT_NAME||"Metropole AI",
 systemPrompt:process.env.SYSTEM_PROMPT||"You are a helpful Discord assistant."
};
const dataDir=path.join(__dirname,"..","data"), historyFile=path.join(dataDir,"history.json");
if(!fs.existsSync(dataDir))fs.mkdirSync(dataDir,{recursive:true});
if(!fs.existsSync(historyFile))fs.writeFileSync(historyFile,"{}");
let history={};try{history=JSON.parse(fs.readFileSync(historyFile,"utf8"))}catch{history={}}
function save(){const t=historyFile+".tmp";fs.writeFileSync(t,JSON.stringify(history,null,2));fs.renameSync(t,historyFile)}
function clean(s){return String(s||"").replace(/\u0000/g,"").trim()}
function splitText(s,max=1900){let a=[];while(s.length>max){let n=s.lastIndexOf("\n",max);if(n<500)n=s.lastIndexOf(" ",max);if(n<1)n=max;a.push(s.slice(0,n));s=s.slice(n).trimStart()}if(s)a.push(s);return a}
async function ask(userId,q){
 const prev=history[userId]||[];
 const input=[{role:"developer",content:C.systemPrompt},...prev.slice(-C.maxHistory),{role:"user",content:q}];
 const r=await fetch("https://api.openai.com/v1/responses",{method:"POST",headers:{"Content-Type":"application/json","Authorization":`Bearer ${C.apiKey}`},body:JSON.stringify({model:C.model,input,max_output_tokens:900})});
 const raw=await r.text();let b={};try{b=JSON.parse(raw)}catch{}
 if(!r.ok)throw new Error(b?.error?.message||`API HTTP ${r.status}`);
 const answer=clean(b.output_text);
 if(!answer)throw new Error("Empty AI response");
 history[userId]=[...prev.slice(-(C.maxHistory-1)),{role:"user",content:q},{role:"assistant",content:answer}];save();
 return answer;
}
const commands=[
 new SlashCommandBuilder().setName("ai").setDescription("Ask Metropole AI").addStringOption(o=>o.setName("question").setDescription("Your question").setRequired(true).setMaxLength(3000)),
 new SlashCommandBuilder().setName("ai-clear").setDescription("Clear your AI history"),
 new SlashCommandBuilder().setName("ai-status").setDescription("Show AI status"),
 new SlashCommandBuilder().setName("ai-setup").setDescription("Show setup information")
].map(x=>x.toJSON());

const client=new Client({intents:[GatewayIntentBits.Guilds,GatewayIntentBits.GuildMessages,GatewayIntentBits.MessageContent],partials:[Partials.Channel]});
const cooldowns=new Map();
client.once("ready",async()=>{
 console.log(`✅ ${client.user.tag} online | Model: ${C.model}`);
 const rest=new REST({version:"10"}).setToken(C.token);
 try{await rest.put(Routes.applicationGuildCommands(C.clientId,C.guildId),{body:commands});console.log("✅ Slash commands registered.");}
 catch(e){console.error("❌ Command registration failed:",e)}
});
client.on("interactionCreate",async i=>{
 if(!i.isChatInputCommand())return;
 if(i.commandName==="ai"){
  if(C.aiChannelId&&i.channelId!==C.aiChannelId)return i.reply({content:`❌ Use AI in <#${C.aiChannelId}>.`,ephemeral:true});
  const now=Date.now(),last=cooldowns.get(i.user.id)||0;
  if(now-last<C.cooldownMs)return i.reply({content:`⏳ Wait ${Math.ceil((C.cooldownMs-(now-last))/1000)}s.`,ephemeral:true});
  cooldowns.set(i.user.id,now);const q=clean(i.options.getString("question"));await i.deferReply();
  try{const ans=await ask(i.user.id,q),parts=splitText(ans,C.maxOutput);await i.editReply(parts[0]);for(const p of parts.slice(1))await i.followUp(p)}
  catch(e){console.error("AI error:",e);await i.editReply("❌ AI is unavailable. Check the API key/model and Pterodactyl console.")}
 }else if(i.commandName==="ai-clear"){
  delete history[i.user.id];save();await i.reply({content:"🧹 Your AI history was cleared.",ephemeral:true});
 }else if(i.commandName==="ai-status"){
  const e=new EmbedBuilder().setTitle(`🤖 ${C.botName}`).setDescription("Separate AI assistant for Metropole Studio.")
   .addFields({name:"Model",value:`\`${C.model}\``,inline:true},{name:"AI Channel",value:C.aiChannelId?`<#${C.aiChannelId}>`:"All",inline:true},{name:"Auto Chat",value:C.autoChatChannelId?`<#${C.autoChatChannelId}>`:"Off",inline:true});
  await i.reply({embeds:[e],ephemeral:true});
 }else if(i.commandName==="ai-setup"){
  if(!i.memberPermissions?.has(PermissionFlagsBits.Administrator)&&i.user.id!==C.ownerId)return i.reply({content:"❌ Admin/Owner only.",ephemeral:true});
  await i.reply({content:"Set OPENAI_API_KEY in `.env`, optionally set AI_CHANNEL_ID/AUTO_CHAT_CHANNEL_ID, then restart with `npm start`. Never share your API key.",ephemeral:true});
 }
});
client.on("messageCreate",async m=>{
 if(m.author.bot||!m.guild||!C.autoChatChannelId||m.channelId!==C.autoChatChannelId||!m.content.trim())return;
 const now=Date.now(),last=cooldowns.get(m.author.id)||0;if(now-last<C.cooldownMs)return;cooldowns.set(m.author.id,now);
 try{await m.channel.sendTyping();const ans=await ask(m.author.id,clean(m.content));for(const p of splitText(ans,C.maxOutput))await m.reply({content:p,allowedMentions:{repliedUser:false}})}
 catch(e){console.error("Auto-chat error:",e);await m.reply({content:"❌ AI is temporarily unavailable.",allowedMentions:{repliedUser:false}}).catch(()=>{})}
});
client.on("error",e=>console.error("Discord error:",e));
process.on("unhandledRejection",e=>console.error("Unhandled rejection:",e));
client.login(C.token);
